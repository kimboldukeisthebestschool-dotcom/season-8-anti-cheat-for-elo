import test from "node:test";
import assert from "node:assert/strict";
import { AntiCheat } from "../src/anti-cheat.js";

test("first movement sample is accepted", () => {
  const ac = new AntiCheat();
  assert.equal(ac.checkMovement("p1", { x: 0, y: 0, z: 0, timestampMs: 1000 }).ok, true);
});

test("flags an extreme movement outlier", () => {
  const ac = new AntiCheat({ movement: { maxHorizontalSpeedPerSecond: 100, tolerance: 1 } });
  ac.checkMovement("p1", { x: 0, y: 0, z: 0, timestampMs: 1000 });
  const result = ac.checkMovement("p1", { x: 1000, y: 0, z: 0, timestampMs: 2000 });
  assert.equal(result.flag, "movement_speed_outlier");
});

test("flags action rate above configured limit", () => {
  const ac = new AntiCheat();
  ac.checkActionRate("p1", "fire", 1000, { windowMs: 1000, maxActions: 1 });
  const result = ac.checkActionRate("p1", "fire", 1100, { windowMs: 1000, maxActions: 1 });
  assert.equal(result.flag, "action_rate_exceeded");
});

test("rejects negative inventory counts", () => {
  const ac = new AntiCheat();
  assert.equal(ac.validateInventoryChange({ itemId: "x", oldCount: -1, newCount: 1 }).flag, "invalid_inventory_change");
});
