# OGFN 8.51 Anti-Cheat Starter (Server-Side)

A small, framework-neutral starter for **server-side validation** in a private OGFN 8.51 test environment. It is not a drop-in plugin and does not bypass or modify Easy Anti-Cheat.

## What it includes
- Configurable thresholds for movement and action-rate checks
- A simple event-validation module
- A small Node.js example showing how to call the validator
- Unit tests using Node's built-in test runner

## Requirements
- Node.js 18+
- Your own private/test server integration

## Run the tests
```bash
npm test
```

## Integrate it
Import `AntiCheat` from `src/anti-cheat.js` and call:
- `checkMovement(playerId, sample)` with server-observed positions and elapsed time
- `checkActionRate(playerId, actionName, nowMs)` when the server receives an action
- `validateInventoryChange(change)` before accepting an inventory update

**Important:** Use authoritative server-side state. Client-reported values alone are not proof of cheating. Tune thresholds for your game's actual movement mechanics and avoid automatic bans based on one flag; log and review repeated signals instead.
