/**
 * Lightweight server-side validation helpers.
 * Feed this module server-observed/authoritative state; do not trust client-only claims.
 */
export class AntiCheat {
  constructor(config = {}) {
    this.config = {
      movement: {
        maxHorizontalSpeedPerSecond: 1800,
        maxVerticalSpeedPerSecond: 2200,
        tolerance: 1.35,
        minimumSampleMs: 50,
        ...config.movement
      },
      actionRate: {
        defaultWindowMs: 1000,
        defaultMaxActions: 30,
        ...config.actionRate
      },
      inventory: {
        maxStackSize: 999,
        maxDeltaPerUpdate: 999,
        ...config.inventory
      }
    };
    this.previousSamples = new Map();
    this.actionHistory = new Map();
  }

  checkMovement(playerId, sample) {
    const { x, y, z, timestampMs } = sample ?? {};
    if (![x, y, z, timestampMs].every(Number.isFinite)) {
      return { ok: false, flag: "invalid_movement_sample" };
    }

    const previous = this.previousSamples.get(playerId);
    this.previousSamples.set(playerId, { x, y, z, timestampMs });
    if (!previous) return { ok: true, flag: null, reason: "first_sample" };

    const elapsedMs = timestampMs - previous.timestampMs;
    if (elapsedMs < this.config.movement.minimumSampleMs) {
      return { ok: true, flag: null, reason: "sample_too_soon" };
    }
    if (elapsedMs <= 0) {
      return { ok: false, flag: "non_monotonic_timestamp" };
    }

    const seconds = elapsedMs / 1000;
    const dx = x - previous.x;
    const dy = y - previous.y;
    const dz = z - previous.z;
    const horizontalSpeed = Math.hypot(dx, y - previous.y) / seconds;
    const verticalSpeed = Math.abs(dz) / seconds;
    const tolerance = this.config.movement.tolerance;

    const tooFastHorizontal =
      horizontalSpeed > this.config.movement.maxHorizontalSpeedPerSecond * tolerance;
    const tooFastVertical =
      verticalSpeed > this.config.movement.maxVerticalSpeedPerSecond * tolerance;

    if (tooFastHorizontal || tooFastVertical) {
      return {
        ok: false,
        flag: "movement_speed_outlier",
        details: { horizontalSpeed, verticalSpeed, elapsedMs }
      };
    }
    return { ok: true, flag: null, details: { horizontalSpeed, verticalSpeed } };
  }

  checkActionRate(playerId, actionName, nowMs, options = {}) {
    if (typeof playerId !== "string" || typeof actionName !== "string" || !Number.isFinite(nowMs)) {
      return { ok: false, flag: "invalid_action_sample" };
    }
    const windowMs = options.windowMs ?? this.config.actionRate.defaultWindowMs;
    const maxActions = options.maxActions ?? this.config.actionRate.defaultMaxActions;
    const key = `${playerId}:${actionName}`;
    const recent = (this.actionHistory.get(key) ?? []).filter(t => nowMs - t < windowMs);
    recent.push(nowMs);
    this.actionHistory.set(key, recent);

    if (recent.length > maxActions) {
      return { ok: false, flag: "action_rate_exceeded", details: { count: recent.length, windowMs, maxActions } };
    }
    return { ok: true, flag: null, details: { count: recent.length, windowMs } };
  }

  validateInventoryChange(change) {
    const { itemId, oldCount, newCount } = change ?? {};
    if (typeof itemId !== "string" || !itemId.trim() ||
        !Number.isInteger(oldCount) || !Number.isInteger(newCount) ||
        oldCount < 0 || newCount < 0) {
      return { ok: false, flag: "invalid_inventory_change" };
    }
    const { maxStackSize, maxDeltaPerUpdate } = this.config.inventory;
    if (newCount > maxStackSize) {
      return { ok: false, flag: "inventory_stack_limit", details: { itemId, newCount, maxStackSize } };
    }
    if (Math.abs(newCount - oldCount) > maxDeltaPerUpdate) {
      return { ok: false, flag: "inventory_delta_outlier", details: { itemId, oldCount, newCount } };
    }
    return { ok: true, flag: null };
  }

  forgetPlayer(playerId) {
    this.previousSamples.delete(playerId);
    for (const key of this.actionHistory.keys()) {
      if (key.startsWith(`${playerId}:`)) this.actionHistory.delete(key);
    }
  }
}
