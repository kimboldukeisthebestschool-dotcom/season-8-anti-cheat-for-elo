import { AntiCheat } from "../src/anti-cheat.js";
import config from "../config.example.json" with { type: "json" };

const antiCheat = new AntiCheat(config);

function recordFlag(playerId, result) {
  if (!result.ok) {
    // Replace with your server's structured logger / moderation queue.
    console.warn("[anti-cheat]", { playerId, ...result });
  }
}

// Illustrative calls only: connect these to authoritative server events.
recordFlag("test-player", antiCheat.checkMovement("test-player", {
  x: 0, y: 0, z: 0, timestampMs: 1000
}));
recordFlag("test-player", antiCheat.checkMovement("test-player", {
  x: 100, y: 0, z: 0, timestampMs: 1100
}));
recordFlag("test-player", antiCheat.checkActionRate("test-player", "fire", 1200, {
  windowMs: 1000, maxActions: 10
}));
recordFlag("test-player", antiCheat.validateInventoryChange({
  itemId: "example-item", oldCount: 1, newCount: 2
}));
